<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2EZAmqd5zX9MFgsm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7DJMiGXhAjRYljFp',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'page-bukutamu',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/create-bukutamu' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'create-bukutamu',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/post-bukutamu' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'simpan-bukutamu',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'page-login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/post-login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'post-login',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'page-logout',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/feedback' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OauQ0MB6aiLvAjQe',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/tambah-feedback' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'page-createfeedback',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard-welcome' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IvwTHVnZrueX3ptK',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard-dataadmin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VVuEO6IrKBwkK8q7',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard-dataadmin/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6PmEd9QRgP58EibH',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard-datapengunjung' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'page-datapengunjung',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/export-datapengunjung' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'page-exportdatapengunjung',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard-datafeedback' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'page-datafeedback',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard-datapegawai' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'page-datapegawai',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard-createpegawai' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'page-createpegawai',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard-datapenduduk' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CEcVROQNeeFKR368',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard-tambahdatart' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'page-creatert',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard-datakepalakeluarga' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WKjCcoXt7xHgZl4i',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard-datakepalakeluarga/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'page-createkk',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard-tambahdatapenduduk' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0QYutSzDmiJoLFPi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/da(?|shboard\\-(?|d(?|ata(?|admin(?|update/([^/]++)(?|(*:61)|/update(*:75))|delete/([^/]++)(*:98))|feedbackdelete/([^/]++)(*:129))|elete(?|rt/([^/]++)(*:157)|kk/([^/]++)(*:176)))|edit(?|pegawai/([^/]++)/(?|profil(*:219)|edit(*:231))|rt/([^/]++)(*:251)|kepalakeluarga/([^/]++)(?|(*:285)|/edit(*:298)))|profil(?|pegawai/([^/]++)/profil(*:340)|delete/([^/]++)(*:363))|updatert/([^/]++)/update(*:396))|tapengunjung\\-(?|delete/([^/]++)(*:437)|update/([^/]++)/update(*:467))))/?$}sDu',
    ),
    3 => 
    array (
      61 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1JzH3LLeYdLq2y5H',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      75 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KiS8orE3gVmSBBca',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      98 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uRX7CCFFcKy0SZ3S',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      129 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OdEowzevDKqHMuhX',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      157 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::syv8TpWuWn2pHi7E',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      176 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JMXrr2Px8Zx7MAhn',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      219 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::D72Ii1vmyN9S1i0y',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      231 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MwdS7hJ5oxv6dB18',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      251 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FOivWRN5puUjLqUX',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      285 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fEW25IF2lajeXuIC',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      298 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mVKfXhv0kQRHdR7x',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      340 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qiTjAxR30UpmQ1Ww',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      363 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WOidCGURz9usjB9k',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      396 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3OsL7tEOONcWbkuo',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      437 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::quCOkJjwzMec5NBF',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      467 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hTXmg9VTkuuQRI1e',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::2EZAmqd5zX9MFgsm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'generated::2EZAmqd5zX9MFgsm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7DJMiGXhAjRYljFp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:295:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:77:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000063e0000000000000000";}";s:4:"hash";s:44:"iZJ1xOmHC8dfXypK5s4ktA/czlYXrRsOOX8rcC6pD8k=";}}',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::7DJMiGXhAjRYljFp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'page-bukutamu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\http\\Controllers\\bukutamuController@index',
        'controller' => 'App\\http\\Controllers\\bukutamuController@index',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'page-bukutamu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'create-bukutamu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'create-bukutamu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\http\\Controllers\\bukutamuController@create',
        'controller' => 'App\\http\\Controllers\\bukutamuController@create',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'create-bukutamu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'simpan-bukutamu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'post-bukutamu',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\http\\Controllers\\bukutamuController@store',
        'controller' => 'App\\http\\Controllers\\bukutamuController@store',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'simpan-bukutamu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'page-login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\http\\Controllers\\loginController@index',
        'controller' => 'App\\http\\Controllers\\loginController@index',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'page-login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'post-login' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'post-login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\http\\Controllers\\loginController@postlogin',
        'controller' => 'App\\http\\Controllers\\loginController@postlogin',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'post-login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'page-logout' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\http\\Controllers\\loginController@logout',
        'controller' => 'App\\http\\Controllers\\loginController@logout',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'page-logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OauQ0MB6aiLvAjQe' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'feedback',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\http\\Controllers\\feedbackController@index',
        'controller' => 'App\\http\\Controllers\\feedbackController@index',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::OauQ0MB6aiLvAjQe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'page-createfeedback' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'tambah-feedback',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\http\\Controllers\\feedbackController@create',
        'controller' => 'App\\http\\Controllers\\feedbackController@create',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'page-createfeedback',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IvwTHVnZrueX3ptK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard-welcome',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin,Manajemen,Pelayanan,KetuaRT',
        ),
        'uses' => 'App\\http\\Controllers\\welcomepageController@index',
        'controller' => 'App\\http\\Controllers\\welcomepageController@index',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::IvwTHVnZrueX3ptK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VVuEO6IrKBwkK8q7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard-dataadmin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin',
        ),
        'uses' => 'App\\http\\Controllers\\dataadminController@index',
        'controller' => 'App\\http\\Controllers\\dataadminController@index',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::VVuEO6IrKBwkK8q7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6PmEd9QRgP58EibH' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'dashboard-dataadmin/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin',
        ),
        'uses' => 'App\\http\\Controllers\\dataadminController@createadmin',
        'controller' => 'App\\http\\Controllers\\dataadminController@createadmin',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::6PmEd9QRgP58EibH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1JzH3LLeYdLq2y5H' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard-dataadminupdate/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin',
        ),
        'uses' => 'App\\http\\Controllers\\dataadminController@updateadminindex',
        'controller' => 'App\\http\\Controllers\\dataadminController@updateadminindex',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::1JzH3LLeYdLq2y5H',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KiS8orE3gVmSBBca' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'dashboard-dataadminupdate/{id}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin',
        ),
        'uses' => 'App\\http\\Controllers\\dataadminController@updateadmin',
        'controller' => 'App\\http\\Controllers\\dataadminController@updateadmin',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::KiS8orE3gVmSBBca',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uRX7CCFFcKy0SZ3S' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard-dataadmindelete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin',
        ),
        'uses' => 'App\\http\\Controllers\\dataadminController@delete',
        'controller' => 'App\\http\\Controllers\\dataadminController@delete',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::uRX7CCFFcKy0SZ3S',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'page-datapengunjung' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard-datapengunjung',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin,Pelayanan',
        ),
        'uses' => 'App\\http\\Controllers\\datapengunjungController@display',
        'controller' => 'App\\http\\Controllers\\datapengunjungController@display',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'page-datapengunjung',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'page-exportdatapengunjung' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'export-datapengunjung',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin,Pelayanan',
        ),
        'uses' => 'App\\http\\Controllers\\datapengunjungController@bukutamuExport',
        'controller' => 'App\\http\\Controllers\\datapengunjungController@bukutamuExport',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'page-exportdatapengunjung',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::quCOkJjwzMec5NBF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'datapengunjung-delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin,Pelayanan',
        ),
        'uses' => 'App\\http\\Controllers\\datapengunjungController@delete',
        'controller' => 'App\\http\\Controllers\\datapengunjungController@delete',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::quCOkJjwzMec5NBF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hTXmg9VTkuuQRI1e' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'datapengunjung-update/{id}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin,Pelayanan',
        ),
        'uses' => 'App\\http\\Controllers\\datapengunjungController@update',
        'controller' => 'App\\http\\Controllers\\datapengunjungController@update',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::hTXmg9VTkuuQRI1e',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::D72Ii1vmyN9S1i0y' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard-editpegawai/{id}/profil',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin,Pelayanan',
        ),
        'uses' => 'App\\http\\Controllers\\datapengunjungController@showeditpengunjung',
        'controller' => 'App\\http\\Controllers\\datapengunjungController@showeditpengunjung',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::D72Ii1vmyN9S1i0y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'page-datafeedback' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard-datafeedback',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin,Manajemen',
        ),
        'uses' => 'App\\http\\Controllers\\feedbackController@feedbackindex',
        'controller' => 'App\\http\\Controllers\\feedbackController@feedbackindex',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'page-datafeedback',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OdEowzevDKqHMuhX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard-datafeedbackdelete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin,Manajemen',
        ),
        'uses' => 'App\\http\\Controllers\\feedbackController@delete',
        'controller' => 'App\\http\\Controllers\\feedbackController@delete',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::OdEowzevDKqHMuhX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'page-datapegawai' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard-datapegawai',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin,Manajemen',
        ),
        'uses' => 'App\\http\\Controllers\\datapegawaiController@index',
        'controller' => 'App\\http\\Controllers\\datapegawaiController@index',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'page-datapegawai',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'page-createpegawai' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'dashboard-createpegawai',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin,Manajemen',
        ),
        'uses' => 'App\\http\\Controllers\\datapegawaiController@create',
        'controller' => 'App\\http\\Controllers\\datapegawaiController@create',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'page-createpegawai',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qiTjAxR30UpmQ1Ww' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard-profilpegawai/{id}/profil',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin,Manajemen',
        ),
        'uses' => 'App\\http\\Controllers\\datapegawaiController@profil',
        'controller' => 'App\\http\\Controllers\\datapegawaiController@profil',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::qiTjAxR30UpmQ1Ww',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MwdS7hJ5oxv6dB18' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'dashboard-editpegawai/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin,Manajemen',
        ),
        'uses' => 'App\\http\\Controllers\\profilpegawaiController@update',
        'controller' => 'App\\http\\Controllers\\profilpegawaiController@update',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::MwdS7hJ5oxv6dB18',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WOidCGURz9usjB9k' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard-profildelete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin,Manajemen',
        ),
        'uses' => 'App\\http\\Controllers\\datapegawaiController@delete',
        'controller' => 'App\\http\\Controllers\\datapegawaiController@delete',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::WOidCGURz9usjB9k',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CEcVROQNeeFKR368' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard-datapenduduk',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin,KetuaRT',
        ),
        'uses' => 'App\\http\\Controllers\\datapendudukController@index',
        'controller' => 'App\\http\\Controllers\\datapendudukController@index',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::CEcVROQNeeFKR368',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'page-creatert' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'dashboard-tambahdatart',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin,KetuaRT',
        ),
        'uses' => 'App\\http\\Controllers\\datapendudukController@tambahrt',
        'controller' => 'App\\http\\Controllers\\datapendudukController@tambahrt',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'page-creatert',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::syv8TpWuWn2pHi7E' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard-deletert/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin,KetuaRT',
        ),
        'uses' => 'App\\http\\Controllers\\datapendudukController@delete',
        'controller' => 'App\\http\\Controllers\\datapendudukController@delete',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::syv8TpWuWn2pHi7E',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FOivWRN5puUjLqUX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard-editrt/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin,KetuaRT',
        ),
        'uses' => 'App\\http\\Controllers\\datapendudukController@editrtindex',
        'controller' => 'App\\http\\Controllers\\datapendudukController@editrtindex',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::FOivWRN5puUjLqUX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3OsL7tEOONcWbkuo' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'dashboard-updatert/{id}/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin,KetuaRT',
        ),
        'uses' => 'App\\http\\Controllers\\datapendudukController@editrt',
        'controller' => 'App\\http\\Controllers\\datapendudukController@editrt',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::3OsL7tEOONcWbkuo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WKjCcoXt7xHgZl4i' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard-datakepalakeluarga',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin,KetuaRT',
        ),
        'uses' => 'App\\http\\Controllers\\datakepalakeluargaController@datakartukeluargaindex',
        'controller' => 'App\\http\\Controllers\\datakepalakeluargaController@datakartukeluargaindex',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::WKjCcoXt7xHgZl4i',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'page-createkk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'dashboard-datakepalakeluarga/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin,KetuaRT',
        ),
        'uses' => 'App\\http\\Controllers\\datakepalakeluargaController@tambahkepalakeluarga',
        'controller' => 'App\\http\\Controllers\\datakepalakeluargaController@tambahkepalakeluarga',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'page-createkk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fEW25IF2lajeXuIC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard-editkepalakeluarga/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin,KetuaRT',
        ),
        'uses' => 'App\\http\\Controllers\\datakepalakeluargaController@editkepalakeluargaindex',
        'controller' => 'App\\http\\Controllers\\datakepalakeluargaController@editkepalakeluargaindex',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::fEW25IF2lajeXuIC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mVKfXhv0kQRHdR7x' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'dashboard-editkepalakeluarga/{id}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin,KetuaRT',
        ),
        'uses' => 'App\\http\\Controllers\\datakepalakeluargaController@editkepalakeluarga',
        'controller' => 'App\\http\\Controllers\\datakepalakeluargaController@editkepalakeluarga',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::mVKfXhv0kQRHdR7x',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0QYutSzDmiJoLFPi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard-tambahdatapenduduk',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin,KetuaRT',
        ),
        'uses' => 'App\\http\\Controllers\\datakepalakeluargaController@tambahkartukeluargaindex',
        'controller' => 'App\\http\\Controllers\\datakepalakeluargaController@tambahkartukeluargaindex',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::0QYutSzDmiJoLFPi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JMXrr2Px8Zx7MAhn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard-deletekk/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'CekLevel:Admin,KetuaRT',
        ),
        'uses' => 'App\\http\\Controllers\\datakepalakeluargaController@delete',
        'controller' => 'App\\http\\Controllers\\datakepalakeluargaController@delete',
        'namespace' => 'App\\http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::JMXrr2Px8Zx7MAhn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
