$('#tanggal').datepicker({
    format: 'yyyy-mm-dd',
    daysOfWeekDisabled: "0",
    autoclose:true
});