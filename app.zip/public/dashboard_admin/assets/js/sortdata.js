$(document).ready(function () {
    $('#example').DataTable({
        order: [[3, 'desc']],
    });
});