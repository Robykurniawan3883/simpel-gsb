<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\bukutamu;

class dashboardController extends Controller
{

    // public function halamanadmin()
    // {
        
    // }

    // public function halamanpelayanan()
    // {
    //     $bukutamu = bukutamu::all();
    //     return view('layouts.dashboard.datapengunjung')->with('bukutamu',$bukutamu);
    // }

    // public function create()
    // {
    //     //
    // }

 
}
