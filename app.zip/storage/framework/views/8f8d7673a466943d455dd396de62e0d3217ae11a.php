

<?php $__env->startSection('content'); ?>


<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="panel">
					<div class="panel-heading">
						<h3 class="panel-title">Ubah Data Kepala Keluarga</h3>
                        <br>
                        <form action="/dashboard-editkepalakeluarga/<?php echo e($datakepalakeluarga->id); ?>/edit" method="post" enctype="multipart/form-data">
							<?php echo e(csrf_field()); ?>

							<?php echo e(method_field('PUT')); ?>


                            <div class="form-group">
								<label class="form-label" for="customFile">Masukkan Scan KK (.pdf) </label>
								<input type="file" name="imagekk" class="form-control" id="customFile" accept="application/pdf" required/>
							</div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Kepala Keluarga</label>
                                <input name="kepalakeluarga" type="text" class="form-control"  aria-describedby="emailHelp" placeholder="Masukkan Kepala Keluarga" value="<?php echo e($datakepalakeluarga->kepalakeluarga); ?>" required>
                            </div>
							<div class="form-group">
                                <label for="exampleInputEmail1">No Kartu Kepala Keluarga</label>
                                <input name="nokk" type="number" class="form-control"  aria-describedby="emailHelp" placeholder="Masukkan No Kartu Keluarga" value="<?php echo e($datakepalakeluarga->nokk); ?>" required>
                            </div>
							<div class="form-group">

                                <label for="exampleInputEmail1">RT</label>
                                <select selected name="datart_id" id="datart_id" class="form-control" aria-label="Pilih RT" required="required">
									<?php $__currentLoopData = $dtrt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->rt); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
							<div class="form-group">
                                <label for="exampleInputEmail1">Tempat Tinggal Kepala Keluarga</label>
                                <input name="tempattinggal" type="text" class="form-control"  aria-describedby="emailHelp" placeholder="Masukkan Tempat Tinggal Kepala Keluarga" value="<?php echo e($datakepalakeluarga->tempattinggal); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">No Telepon Kepala Keluarga</label>
                                <input name="notelepon" type="number" class="form-control"  aria-describedby="emailHelp" placeholder="Masukkan No Telepon Kepala Keluarga" value="<?php echo e($datakepalakeluarga->notelepon); ?>" required>
                            </div>
							<div class="form-group">
                                <label for="exampleInputEmail1">Jumlah Keluarga</label>
                                <input name="jumlahkeluarga" type="number" class="form-control"  aria-describedby="emailHelp" placeholder="Masukkan Jumlah Keluarga" value="<?php echo e($datakepalakeluarga->jumlahkeluarga); ?>" required>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Ubah Data</button>
                        </form>
						</div>
					</div>
				</div>

                        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SIMPEL-GSB\resources\views/layouts/datapenduduk/editkepalakeluarga.blade.php ENDPATH**/ ?>