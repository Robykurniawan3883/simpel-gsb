

<?php $__env->startSection('content'); ?>

		<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<h3 class="page-title">Saran dan Masukkan Masyarakat</h3>
				</div>


                <div class="row">
                <?php $__currentLoopData = $feedback; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                    
                        <!-- PANEL WITH FOOTER -->
                        <div class="panel">
                            <div class="panel-heading">
                                <h3 class="panel-title"><?php echo e($feedback->nama); ?></h3>
                                <div class="right">
                                    <button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
                                    <button type="button" class="btn-remove"><i class="lnr lnr-cross"></i></button>
                                </div>
                            </div>
                            <div class="panel-body">
                                <p><?php echo e($feedback->feedback); ?></p>
                            </div>
                            <div class="panel-footer">
                                <a class="btn btn-danger" href="/dashboard-datafeedbackdelete/<?php echo e($feedback->id); ?>">Hapus Saran</button></a>
                                <!-- <button type="button" class="btn btn-danger" href="/dashboard-datafeedbackdelete/<?php echo e($feedback->id); ?>">Delete</button> -->
                            </div>
                        </div>
                        <!-- END PANEL WITH FOOTER -->
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                    
       


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bukutamu\resources\views/layouts/dashboard/datafeedback.blade.php ENDPATH**/ ?>