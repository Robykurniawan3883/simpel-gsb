

<?php $__env->startSection('content'); ?>
    
    <!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="panel">
					<div class="panel-heading">
						<h3 class="panel-title">Data RT Kelurahan Gunung Samarinda Baru</h3>
						<div class="right">
							<button type="button" class="btn btn-default" data-toggle="modal" data-target="#exampleModal">Tambah RT</button>
						</div>
					</div>
					<div class="panel-body no-padding">
						<table class="table table-hover">
							<thead>
								<tr>
									<!-- <th>No</th> -->
									<th>Id RT.</th>
									<th>RT</th>
									<th>Ketua RT</th>
                                    <th>Alamat RT</th>
									<th>Jumlah Kk</th>
                                    <th>Action</th>

								</tr>
							</thead>
							<tbody>
                            <?php $__currentLoopData = $datart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
                                    <td><?php echo e($datart->idrt); ?></td>
									<td><a href=""><?php echo e($datart->rt); ?></a></td>
                                    <th><?php echo e($datart->ketuart); ?></th>
									<td><?php echo e($datart->alamatrt); ?></td>
									<td>100 KK</td>
                                    <td><a class="btn btn-success" href="/dashboard-editrt/<?php echo e($datart->id); ?>">Edit</button><a class="btn btn-danger" href="/dashboard-deletert/<?php echo e($datart->id); ?>">Delete</button></td>
								</tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
					<div class="panel-footer">
						<div class="row">
							<div class="col-md-6"><span class="panel-note">Data Penduduk</span></div>
						</div>
					</div>
				</div>
			<!-- END MAIN CONTENT -->
            
             <!-- Modal -->
	            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Tambah Data RT</h5>
                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                            </button>
                        </div>
                        <div class="modal-body">
                        <form action="<?php echo e(url('/dashboard-tambahdatart')); ?>" method="post" enctype="multipart/form-data">
						<?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label for="exampleInputEmail1">RT</label>
                                <input name="rt" type="text" class="form-control"  aria-describedby="emailHelp" placeholder="Masukkan RT" required>
                            </div>
							<div class="form-group">
                                <label for="exampleInputEmail1">Ketua RT</label>
                                <input name="ketuart" type="text" class="form-control"  aria-describedby="emailHelp" placeholder="Masukkan Ketua RT" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">ID RT (Jika rt 30 adalah urutan pertama beri 1 dan seterusnya)</label>
                                <input name="idrt" type="text" class="form-control"  aria-describedby="emailHelp" placeholder="Masukkan ID RT" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Alamat RT</label>
                                <input name="alamatrt" type="text" class="form-control"  aria-describedby="emailHelp" placeholder="Masukkan Lokasi RT" required>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Tambah</button>
                        </form>
						</div>
					</div>
				</div>

                
						<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bukutamu\resources\views/layouts/datapenduduk/datart.blade.php ENDPATH**/ ?>