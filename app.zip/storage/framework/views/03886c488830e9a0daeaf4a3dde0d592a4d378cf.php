

<?php $__env->startSection('content'); ?>
    
    <!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="panel">
					<div class="panel-heading">
						<h3 class="panel-title">Selamat Datang di Data Admin</h3>
						<div class="right">
							<button type="button" class="btn btn-default" data-toggle="modal" data-target="#exampleModal">Tambah Admin</button>
						</div>
					</div>
					<div class="panel-body no-padding">
						<table class="table table-striped">
							<thead>
								<tr>
									<th>No.</th>
									<th>Nama</th>
									<th>Email</th>
									<th>Level</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
							<?php $__currentLoopData = $User; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
								
									<td><?php echo e($loop->iteration); ?></td>
									<td><?php echo e($user->name); ?></td>
									<td><?php echo e($user->email); ?></td>
									<td><?php echo e($user->level); ?></td>
									<td><a class="btn btn-link" href="/dashboard-dataadminupdate/<?php echo e($user->id); ?>">Edit</button> <a class="btn btn-danger" href="/dashboard-dataadmindelete/<?php echo e($user->id); ?>">Delete</button></td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
					<div class="panel-footer">
						<div class="row">
							<div class="col-md-6"><span class="panel-note">Data Admin Kelurahan Gunung Samarinda Baru</span></div>
						</div>
					</div>
				</div>
			<!-- END MAIN CONTENT -->

	 <!-- Modal -->
	 <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Tambah Admin</h5>
                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                            </button>
                        </div>
                        <div class="modal-body">
                        <form action="/dashboard-dataadmin/create" method="post" enctype="multipart/form-data">
						<?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Nama Lengkap</label>
                                <input name="name" type="text" class="form-control"  aria-describedby="emailHelp" placeholder="Masukkan Nama Lengkap" required>
                            </div>
							<div class="form-group">
                                <label for="exampleInputEmail1">Email</label>
                                <input name="email" type="text" class="form-control"  aria-describedby="emailHelp" placeholder="Masukkan Email" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Level Akun</label>
                                <select name="level" class="form-control" aria-label="Pilih Role" required="required">
                                    <option value="Admin">Admin</option>
									<option value="Pelayanan">Pelayanan</option>
									<option value="Manajemen">Manajemen</option>
									<option value="KetuaRT">KetuaRT</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Password</label>
                                <input name="password" type="text" class="form-control" aria-describedby="emailHelp" placeholder="Masukkan No Telepon" required>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Tambah Admin</button>
                        </form>
						</div>
					</div>
				</div>
				<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

				
						<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SIMPEL-GSB\resources\views/layouts/dashboard_kelola_admin/dataadmin.blade.php ENDPATH**/ ?>