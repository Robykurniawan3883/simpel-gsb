

<?php $__env->startSection('content'); ?>


<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="panel">
					<div class="panel-heading">
						<h3 class="panel-title">Ubah Data RT</h3>
                        <form action="/dashboard-updatert/<?php echo e($datart->id); ?>/update" method="post">
							<?php echo e(csrf_field()); ?>

							<?php echo e(method_field('PUT')); ?>


                            <div class="form-group">
                                <label for="exampleInputEmail1">RT</label>
                                <input name="rt" type="text" class="form-control"  aria-describedby="emailHelp" placeholder="Masukkan RT" value="<?php echo e($datart->rt); ?>" required>
                            </div>
							<div class="form-group">
                                <label for="exampleInputEmail1">Ketua RT</label>
                                <input name="ketuart" type="text" class="form-control"  aria-describedby="emailHelp" placeholder="Masukkan Ketua RT" value="<?php echo e($datart->ketuart); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">ID RT (Jika rt 30 adalah urutan pertama beri 1 dan seterusnya)</label>
                                <input name="idrt" type="text" class="form-control"  aria-describedby="emailHelp" placeholder="Masukkan ID RT" value="<?php echo e($datart->idrt); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Alamat RT</label>
                                <input name="alamatrt" type="text" class="form-control"  aria-describedby="emailHelp" placeholder="Masukkan Lokasi RT" value="<?php echo e($datart->alamatrt); ?>" required>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Ubah</button>
                        </form>

                        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bukutamu\resources\views/layouts/datapenduduk/editrt.blade.php ENDPATH**/ ?>