

<?php $__env->startSection('content'); ?>
<!-- MAIN -->
<div class="main">
	<!-- MAIN CONTENT -->
	<div class="main-content">
		<div class="container-fluid">

				<!-- OVERVIEW -->
				<div class="panel panel-headline">
				<div class="panel-heading">
					<h3 class="panel-title">Data Kependudukan RT 30</h3>
					<p class="panel-subtitle">Sistem Informasi Manajemen dan Pelayanan <br>Kelurahan Gunung Samarinda Baru Kota Balikpapan</p>
				</div>
				<div class="panel-body">
					<div class="row">
						<div class="col-md-6">
							<div class="metric">
								<span class="icon"><i class="fa fa-download"></i></span>
								<p>
									<span class="number">10</span>
									<span class="title">KEPALA KELUARGA</span>
								</p>
							</div>
						</div>
						<div class="col-md-6">
							<div class="metric">
								<span class="icon"><i class="fa fa-shopping-bag"></i></span>
								<p>
									<span class="number">11</span>
									<span class="title">JIWA</span>
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- END OVERVIEW -->
			<div class="row">
				<div class="col-md-12">
					<!-- RECENT PURCHASES -->
					<div class="panel">
						<div class="panel-heading">
							<h3 class="panel-title">Data Pengunjung</h3>
							<div class="right">
								<button type="button" class="btn btn-default" data-toggle="modal" data-target="#exampleModal">Tambah Kepala Keluarga</button>
							</div>
						</div>
						<div class="panel-body no-padding">
							<table class="table table-striped">
								<thead>
									<tr>
										<th>No.</th>
										<th>Kepala Keluarga</th>
										<th>No Kartu Keluarga</th>
										<th>Tempat Tinggal</th>
										<th>No Telepon</th>
										<th>Jumlah Keluarga</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
										<th><a class="btn btn-secondary" href="">Edit</button> <a class="btn btn-danger" href="">Delete</button></th>
									</tr>
								</tbody>
							</table>
						</div>
						<div class="panel-footer">
							<div class="row">
								<div class="col-md-6"><span class="panel-note"><i class="fa fa-clock-o"></i> Last 24 hours</span></div>
								<div class="col-md-6 text-right"><a href="/export-datapengunjung" class="btn btn-primary"><i class="bi bi-file-spreadsheet"></i>Export to Excel</a></div>
							</div>
						</div>
					</div>
					<!-- END RECENT PURCHASES -->
				</div>
			</div>
			<!-- END MAIN CONTENT -->
            
             <!-- Modal -->
	            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Tambah Kepala Keluarga</h5>
                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                            </button>
                        </div>
                        <div class="modal-body">
                        <form action="" method="post" enctype="multipart/form-data">
						<?php echo e(csrf_field()); ?>

							<div class="form-group">
                                <input name="rt" type="hidden" class="form-control"  aria-describedby="emailHelp" placeholder="Masukkan RT" value="" readonly>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Kepala Keluarga</label>
                                <input name="rt" type="text" class="form-control"  aria-describedby="emailHelp" placeholder="Masukkan Kepala Keluarga" required>
                            </div>
							<div class="form-group">
                                <label for="exampleInputEmail1">No Kartu Kepala Keluarga</label>
                                <input name="ketuart" type="text" class="form-control"  aria-describedby="emailHelp" placeholder="Masukkan No Kartu Keluarga" required>
                            </div>
							<div class="form-group">
                                <label for="exampleInputEmail1">Tempat Tinggal Kepala Keluarga</label>
                                <input name="ketuart" type="text" class="form-control"  aria-describedby="emailHelp" placeholder="Masukkan Tempat Tinggal Kepala Keluarga" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">No Telepon Kepala Keluarga</label>
                                <input name="alamatrt" type="text" class="form-control"  aria-describedby="emailHelp" placeholder="Masukkan No Telepon Kepala Keluarga" required>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Tambah</button>
                        </form>
						</div>
					</div>
				</div>

                
						<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SIMPEL-GSB\resources\views/layouts/datapenduduk/datapenduduk.blade.php ENDPATH**/ ?>