

<?php $__env->startSection('content'); ?>


<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="panel">
					<div class="panel-heading">
						<h3 class="panel-title">Edit Data Admin</h3>
                        <br>
                        <form action="/dashboard-dataadminupdate/<?php echo e($User->id); ?>/update" method="post">
							<?php echo e(csrf_field()); ?>

							<?php echo e(method_field('PUT')); ?>


                            <div class="form-group">
                                <label for="exampleInputEmail1">Nama Lengkap</label>
                                <input name="name" type="text" class="form-control"  aria-describedby="emailHelp" placeholder="Masukkan Nama Lengkap" required value="<?php echo e($User->name); ?>">
                            </div>
							<div class="form-group">
                                <label for="exampleInputEmail1">Email</label>
                                <input name="email" type="text" class="form-control"  aria-describedby="emailHelp" placeholder="Masukkan Email" required value="<?php echo e($User->email); ?>">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Level Akun</label>
                                <select name="level" class="form-control" aria-label="Pilih Role" required="required">
                                    <option value="Admin">Admin</option>
									<option value="Pelayanan">Pelayanan</option>
									<option value="Manajemen">Manajemen</option>
                                    <option value="KetuaRt">KetuaRT</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Password</label>
                                <input name="password" type="text" class="form-control" aria-describedby="emailHelp" placeholder="Masukkan No Telepon" required>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Ubah Data Admin</button>
                        </form>

                        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard_sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SIMPEL-GSB\resources\views/layouts/dashboard_kelola_admin/editadmin.blade.php ENDPATH**/ ?>