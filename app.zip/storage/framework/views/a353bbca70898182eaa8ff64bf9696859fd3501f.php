

<?php $__env->startSection('content'); ?>
<!-- MAIN -->
<div class="main">
	<!-- MAIN CONTENT -->
	<div class="main-content">
		<div class="container-fluid">

				<!-- OVERVIEW -->
				<div class="panel panel-headline">
				<div class="panel-heading">
					<h3 class="panel-title">Selamat Datang Di SIMPEL</h3>
					<p class="panel-subtitle">Sistem Informasi Manajemen dan Pelayanan <br>Kelurahan Gunung Samarinda Baru Kota Balikpapan</p>
				</div>
				<div class="panel-body">
					<div class="row">
						<div class="col-md-6">
							<div class="metric">
								<span class="icon"><i class="lnr lnr-enter"></i></span>
								<p>
									<span class="number"><?php echo e(totalpengunjung()); ?></span>
									<span class="title">Pengunjung</span>
								</p>
							</div>
						</div>
						<div class="col-md-6">
							<div class="metric">
								<span class="icon"><i class="lnr lnr-users"></i></span>
								<p>
									<span class="number"><?php echo e(totalpegawai()); ?></span>
									<span class="title">Jumlah Pegawai</span>
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- END OVERVIEW -->
			<div class="row">
				<div class="col-md-12">
					<!-- RECENT PURCHASES -->
					<div class="panel">
						<div class="panel-heading">
							<h3 class="panel-title">Data Pengunjung</h3>
							<div class="right">
								<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
								<button type="button" class="btn-remove"><i class="lnr lnr-cross"></i></button>
							</div>
						</div>
						<div class="panel-body no-padding">
							<table class="table table-striped">
								<thead>
									<tr>
										<th>No.</th>
										<th>Nama</th>
										<th>Nik</th>
										<th>Alamat</th>
										<th>No Telepon</th>
										<th>Menemui</th>
										<th>Keperluan</th>
										<th>Waktu</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									<?php $__currentLoopData = $bukutamu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bukutamu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										
										<td><?php echo e($loop->iteration); ?></td>
										<td><?php echo e($bukutamu->nama); ?></td>
										<td><?php echo e($bukutamu->nik); ?></td>
										<td><?php echo e($bukutamu->alamat); ?></td>
										<td><?php echo e($bukutamu->notelepon); ?></td>
										<td><?php echo e($bukutamu->menemui); ?></td>
										<td><?php echo e($bukutamu->keperluan); ?></td>
										<td><?php echo e($bukutamu->waktu); ?></td>
										<th><a class="btn btn-secondary" href="/dashboard-editpegawai/<?php echo e($bukutamu->id); ?>/profil">Edit</button> <a class="btn btn-danger" href="/datapengunjung-delete/<?php echo e($bukutamu->id); ?>">Delete</button></th>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
							</table>
						</div>
						<div class="panel-footer">
							<div class="row">
								<div class="col-md-6"><span class="panel-note"><i class="fa fa-clock-o"></i> Data Pengunjung Kelurahan Gunung Samarinda Baru Kota Balikpapan</span></div>
								<div class="col-md-6 text-right"><a class="btn btn-primary" href="/export-datapengunjung" title="Export To Excel" ><i class="lnr lnr-download"></i> <span>Export To Excel</span></a></div>
								<!-- <div class="col-md-6 text-right"><a href="/export-datapengunjung" class="btn btn-primary"><li class="lnr lnr-file-empty"></li>Export to Excel</a></div> -->
							</div>
						</div>
					</div>
					<!-- END RECENT PURCHASES -->
				</div>
			</div>
			<!-- END MAIN CONTENT -->


			<?php $__env->stopSection(); ?>

			
<?php echo $__env->make('layouts.dashboard_sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SIMPEL-GSB\resources\views/layouts/dashboard/datapengunjung.blade.php ENDPATH**/ ?>